import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  ClipboardList,
  Package,
  Users,
  CreditCard,
  LogOut,
} from "lucide-react";
import { useTranslation } from "react-i18next";

const AdminSidebar = () => {
  const location = useLocation();
  const { t } = useTranslation("admin");

  const menuItems = [
    { icon: LayoutDashboard, label: t("sidebar.dashboard"), href: "/admin/dashboard" },
    { icon: ClipboardList, label: t("sidebar.orders"), href: "/admin/orders" },
    { icon: Package, label: t("sidebar.services"), href: "/admin/services" },
    { icon: Users, label: t("sidebar.users"), href: "/admin/users" },
    { icon: CreditCard, label: t("sidebar.payments"), href: "/admin/payments" },
  ];

  return (
    <aside className="w-64 bg-sidebar border-l border-sidebar-border flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-sidebar-border">
        <Link to="/admin/dashboard" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">A</span>
          </div>
          <div>
            <span className="font-bold text-lg text-sidebar-foreground">STAALKER</span>
            <p className="text-xs text-sidebar-muted">{t("brand.subtitle")}</p>
          </div>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1 overflow-auto">
        <p className="px-4 py-2 text-xs font-medium text-sidebar-muted uppercase tracking-wider">
          {t("sidebar.management")}
        </p>
        {menuItems.map((item) => {
          const isActive = location.pathname === item.href;
          return (
            <Link
              key={item.href}
              to={item.href}
              className={`sidebar-item ${isActive ? "sidebar-item-active" : ""}`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-sidebar-border">
        <button 
          onClick={() => {
            // TODO: Clear auth token/session
            localStorage.removeItem('token');
            window.location.href = '/login';
          }}
          className="sidebar-item w-full text-destructive hover:bg-destructive/10"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm font-medium">{t("sidebar.logout")}</span>
        </button>
      </div>
    </aside>
  );
};

export default AdminSidebar;
